Requirements:
Python 3.7, OpenCV, Numpy, Urllib

Instructions:
1. Open Anaconda Powershell Prompt
2. Run the code as below:(ORACLE PARK)
   python assignment3.py 37.753051 -122.205149 37.748436 -122.197253
3. The output images will be generated in the same path where the code exists.(We have placed them in a seperate folder named    Output)
4. The final image will be stored under the name "result.jpeg"
	 